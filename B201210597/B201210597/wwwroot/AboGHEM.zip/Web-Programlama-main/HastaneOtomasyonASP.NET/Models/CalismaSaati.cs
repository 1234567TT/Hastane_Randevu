﻿namespace HastaneOtomasyonASP.NET.Models
{
	public class CalismaSaati
	{

        public int Id { get; set; }
		public string Saat { get; set; }
    }
}
