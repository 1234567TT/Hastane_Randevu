﻿namespace HastaneOtomasyonASP.NET.Utility
{
    public static class UserRoles
    {

        public const string Role_Admin = "Admin";
        public const string Role_Hasta = "Hasta";



    }
}
