# HastaneOtomasyonASP.NET
Web Programlama Proje 
<h1>Anasayfa</h1>


![Screenshot_16](https://github.com/MustfaOzcan/HastaneOtomasyonASP.NET/assets/103693735/6637224b-df08-4b6b-bd3d-e05eaaf9ce21)

<h1>Login Sayfası</h1>

![image](https://github.com/MustfaOzcan/HastaneOtomasyonASP.NET/assets/103693735/55185b0b-9957-40b9-84e3-ee0d370be356)

giriş yaptığımızda karşımıza Ana sayfa çıkıyor.
Admin olarak giriş yaptığımızda  Ekle /Güncelle/ Sil Fonksiyonları sitede beliriyor.
<h1>Doktorlar Sayfası</h1>

![image](https://github.com/MustfaOzcan/HastaneOtomasyonASP.NET/assets/103693735/0077cb27-afd9-4674-9f17-9926b4e3c498)



<h1>Randevu Alma</h1>
Randevu alma hem hasta hem de doktor (admin)’e açıktır ancak üye olmayan giriş yapmayan kişiler erişemez

![image](https://github.com/MustfaOzcan/HastaneOtomasyonASP.NET/assets/103693735/32bbad70-7005-41d5-abb9-b63e7899afb0)


<h1>Randevu Listesi </h1>

![image](https://github.com/MustfaOzcan/HastaneOtomasyonASP.NET/assets/103693735/7594adc3-696c-4f0e-90da-2e2c776253e1)
 	
<h1>Çoklu Dil Desteği </h1>

![image](https://github.com/MustfaOzcan/HastaneOtomasyonASP.NET/assets/103693735/5519182a-1d5d-4250-b23d-317758f71ae9)


 <h1>API</h1>
Bir siteden API ile bilgiler alınıp LINQ ile id’si çift olanlar 
listeleniyor 

 ![image](https://github.com/MustfaOzcan/HastaneOtomasyonASP.NET/assets/103693735/1a176de8-13af-4c20-b111-f0b3bcf453f8)


 <h1>Polikinlikler 
 </h1>

![image](https://github.com/MustfaOzcan/HastaneOtomasyonASP.NET/assets/103693735/91ba9944-bd2e-49f9-b7c4-61c3ef762339)


 <h1>İletişim Sayfası
</h1>

 ![image](https://github.com/MustfaOzcan/HastaneOtomasyonASP.NET/assets/103693735/c4f84e81-1552-4d84-83f6-2319e7c0a1e6)



 


 <h1>Veri Tabanı (SQL Server) </h1>


 ![image](https://github.com/MustfaOzcan/HastaneOtomasyonASP.NET/assets/103693735/512d493b-64e6-466a-b2c7-27326854c969)



 <h1> Proje Raporu: </h1>
[WebProgramlama.docx](https://github.com/MustfaOzcan/HastaneOtomasyonASP.NET/files/13746392/WebProgramlama.docx)
